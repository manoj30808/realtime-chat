<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                <?php echo Form::model($item, array('method' => 'POST', 'url' => 'user/profile','class'=>'form-horizontal')); ?>

                <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">First Name</label>
                    <div class="col-sm-6">
                        <?php echo Form::text('first_name',null,array('class'=>'form-control')); ?>

                        <?php echo $errors->first('first_name', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Last Name</label>
                    <div class="col-sm-6">
                        <?php echo Form::text('last_name',null,array('class'=>'form-control')); ?>

                        <?php echo $errors->first('last_name', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-6">
                        <?php echo Form::text('email',null,array('class'=>'form-control')); ?>

                        <?php echo $errors->first('email', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                
                <?php if(isset($item->is_profile_updated) && !empty($item->is_profile_updated) ): ?>
                <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-6">
                        <?php echo Form::password('password',array('class'=>'form-control')); ?>

                        <?php echo $errors->first('password', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('password_confirmation') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Confirm Password</label>
                    <div class="col-sm-6">
                        <?php echo Form::password('password_confirmation',array('class'=>'form-control')); ?>

                        <?php echo $errors->first('password_confirmation', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <?php endif; ?>

                <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Gender</label>
                    <div class="col-sm-6">
                        <?php echo Form::select('gender',['Male'=>'Male','Female'=>'Female'],old('gender'),array('class'=>'form-control')); ?>

                        <?php echo $errors->first('gender', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('dob') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Date Of Birth</label>
                    <div class="col-sm-6">
                        <?php echo Form::text('dob',old('dob'),array('class'=>'form-control mydatepicker')); ?>

                        <?php echo $errors->first('dob', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Street Address</label>
                    <div class="col-sm-6">
                        <?php echo Form::text('address',old('address'),array('class'=>'form-control')); ?>

                        <?php echo $errors->first('address', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                           
                <div class="form-group <?php echo e($errors->has('home_contact_num') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Phone</label>
                    <div class="col-sm-2">
                        <?php echo Form::text('home_contact_ext',old('home_contact_ext'),array('class'=>'form-control','placeholder'=>'Extension','data-mask'=>"9999")); ?>

                        <?php echo $errors->first('home_contact_ext', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="col-sm-4">
                        <?php echo Form::text('home_contact_num',old('home_contact_num'),array('class'=>'form-control','placeholder'=>'Office Phone Num','placeholder'=>'Home Phone Num','size'=>'10','data-mask'=>"999 999-9999")); ?>

                        <?php echo $errors->first('home_contact_num', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('interest') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Interests</label>
                    <div class="col-sm-6">
                        <?php echo Form::select('interest[]',$interest,old('interest',explode(',', $item['interest'])),array('class'=>'form-control','multiple'=>'multiple')); ?>

                        <?php echo $errors->first('interest', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('skill') ? 'has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Skill</label>
                    <div class="col-sm-6">
                        <?php echo Form::select('skill[]',$skill,old('skill',explode(',', $item['skill'])),array('class'=>'form-control','multiple'=>'multiple')); ?>

                        <?php echo $errors->first('skill', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>
                
                <div class="form-group m-b-0">
                    <div class="col-sm-offset-3 col-sm-9">
                        <button type="submit" name="save" class="btn btn-info waves-effect waves-light m-t-10">Update</button>
                        <a class="btn btn-danger waves-effect waves-light m-t-10" href="<?php echo e(url('home')); ?>">Cancel</a>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>