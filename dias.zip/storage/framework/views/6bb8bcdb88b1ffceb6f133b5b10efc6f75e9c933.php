<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('plugins/images/favicon.png')); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="<?php echo e(asset('plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css')); ?>" rel="stylesheet">
    <!-- morris CSS -->
    <link href="<?php echo e(asset('plugins/bower_components/morrisjs/morris.css')); ?>" rel="stylesheet">
    <!-- animation CSS -->
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-tagsinput.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/custom.css')); ?>" id="theme" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <!-- color CSS -->
    <link href="<?php echo e(asset('css/colors/blue-dark.css')); ?>" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="fix-sidebar">
    <!-- Preloader -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
        </svg>
    </div>
    <div id="wrapper">
        <?php echo $__env->make('layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.partials.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><?php echo e($module_name); ?> <small><?php echo e(isset($title)?$title:''); ?></small></h4> 
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <?php $segments = Request::segments();?>
                        <?php if(!empty($segments)): ?>
                            <ol class="breadcrumb">
                                <li <?php echo e((( Request::segment(1)=='home') ? 'class=active' : '')); ?>><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
                                <?php if(isset($module_name)): ?>
                                    <li class="active"><a href="<?php echo e(url(Request::segment(1))); ?>"><?php echo e($module_name); ?></a></li>
                                <?php endif; ?>
                                <?php if(isset($title)): ?>
                                    <li class="active"><?php echo e(ucfirst($title)); ?></li>
                                <?php endif; ?>
                            </ol>
                        <?php endif; ?>
                    </div>
                </div>
                <?php echo $__env->make('layouts.partials.notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <footer class="footer text-center"> <?php echo e(date('Y')); ?> &copy; Copy right by <?php echo e(config('setup.project_full_name', 'Laravel')); ?> </footer>
            </div>
        </div>
    </div>
    
    <script src="<?php echo e(asset('plugins/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js')); ?>"></script>
    <!--slimscroll JavaScript -->
    <script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('js/waves.js')); ?>"></script>
    <!--Counter js -->
    <script src="<?php echo e(asset('plugins/bower_components/waypoints/lib/jquery.waypoints.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/counterup/jquery.counterup.min.js')); ?>"></script>
    <!--Morris JavaScript -->
    <script src="<?php echo e(asset('plugins/bower_components/raphael/raphael-min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/morrisjs/morris.js')); ?>"></script>
    <!-- chartist chart -->
    <script src="<?php echo e(asset('plugins/bower_components/chartist-js/dist/chartist.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js')); ?>"></script>
    <!-- Calendar JavaScript -->
    <script src="<?php echo e(asset('plugins/bower_components/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/calendar/dist/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/calendar/dist/cal-init.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mask.js')); ?>"></script>
    <!-- Custom tab JavaScript -->
    <script src="<?php echo e(asset('js/cbpFWTabs.js')); ?>"></script>
    <script type="text/javascript">
    $('.mydatepicker').datepicker({
        autoclose: true,
        todayHighlight: true,
        format: 'yyyy-mm-d'
    });
    $('select').select2();
    (function() {
        [].slice.call(document.querySelectorAll('.sttabs')).forEach(function(el) {
            new CBPFWTabs(el);
        });
    })();
    </script>
    <script src="<?php echo e(asset('plugins/bower_components/toast-master/js/jquery.toast.js')); ?>"></script>
    <!--Style Switcher -->
    <script src="<?php echo e(asset('plugins/bower_components/styleswitcher/jQuery.style.switcher.js')); ?>"></script>
</body>

</html>