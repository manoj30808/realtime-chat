<?php $__env->startSection('content'); ?>
<section id="wrapper" class="new-login-register">
    <div class="new-login-box">
        <div class="white-box">
            <?php echo $__env->make('layouts.partials.notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h3 class="box-title m-b-0">Sign up to Panel</h3>
            <small>Enter your details below</small>
            <form class="form-horizontal new-lg-form" role="form" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?> <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                    <div class="col-xs-6">
                        <input id="first_name" type="text" class="form-control" placeholder="First Name" name="first_name" value="<?php echo e(old('first_name')); ?>" required autofocus>
                        <?php if($errors->has('first_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('first_name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xs-6">
                        <input id="last_name" type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus placeholder="Last Name">
                        <?php if($errors->has('last_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('last_name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <div class="col-xs-12">
                        <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(ucfirst('email')); ?>">
                        <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('phone_no') ? ' has-error' : ''); ?>">
                    <div class="col-xs-4">
                        <?php echo Form::text('ext',old('ext'),array('class'=>'form-control','placeholder'=>'Extension','data-mask'=>"9999")); ?>

                        <?php if($errors->has('ext')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('phone_no')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xs-8">
                        <?php echo Form::text('phone_no',old('phone_no'),array('class'=>'form-control','placeholder'=>'Phone No','data-mask'=>"999 999-9999")); ?>

                        <?php if($errors->has('phone_no')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('phone_no')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <div class="col-xs-12">
                        <input id="password" type="password" class="form-control"  placeholder="Password" name="password" required>
                        <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-12">
                        <input id="password-confirm" placeholder="Confirm Password" type="password" class="form-control" name="password_confirmation" required>
                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>" style="margin-left: 0.5%;">
                    <?php echo Form::captcha(); ?>

                    <?php if($errors->has('g-recaptcha-response')): ?> <span class="help-block"> <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong> </span> <?php endif; ?>
                </div>
                <div class="form-group text-center m-t-20">
                    <div class="col-xs-12">
                        <button class="btn btn-info btn-lg btn-block btn-rounded  text-uppercase waves-effect waves-light" type="submit">Sign Up</button>
                    </div>
                </div>
                <div class="form-group m-b-0">
                    <div class="col-sm-12 text-center">
                        <p>Already have an account? <a href="<?php echo e(route('login')); ?>" class="text-danger m-l-5"><b>Sign In</b></a></p>
                    </div>
                </div>
            </form>
            <?php echo Captcha::script(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>