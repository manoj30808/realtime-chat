<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                <div class="box-header">
                    <h3 class="panel-title">Give permission for role : <strong> <?php echo e($role['name']); ?></strong></h3>
                </div>
                <div class="box-body">
                   <?php echo Form::open(array('url' => $ctrl_url.'/'.$role['id'].'/permission','class'=>'form-inline')); ?>

                   <div class="pull-right">
                   
                   </div>
                    <div class="clearfix">
                        <table id="example1" class="table table-bordered table-condensed">
                            <?php if(!empty($items)): ?>
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Name</th>
                                    <th>Display Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo Form::checkbox('permissions[]',$value->id,(in_array($value->id,$selected_perm)?TRUE:FALSE),array('class'=>'permissions')); ?></td>
                                    <th><?php echo e($value->name); ?></th>
                                    <td><?php echo e($value->display_name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php else: ?>
                            <tbody>
                                <tr>
                                    <th>There are no records</th>
                                </tr>
                            </tbody>
                            <?php endif; ?>
                        </table>
                    </div>
                    <button type="submit" name="save" class="btn btn-success">Save</button>
                    <?php echo Form::close(); ?>

               </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
(function() {
    $(document).ready(function(){
        $('.select-all').click(function(){
            if($(this).prop('checked')){
                $('.permissions').prop('checked',true);
            }else{
                $('.permissions').prop('checked',false);
            }
        });
    });
})(jQuery);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>