<?php $__env->startSection('secondary-menu'); ?>
<ul class="nav navbar-nav navbar-right">
	<li><a href="<?php echo e(url($ctrl_url)); ?>"><span class="glyphicon glyphicon-align-justify"></span> List</a></li>
	<li><a href="<?php echo e(url($ctrl_url.'/create')); ?>"><span class="glyphicon glyphicon-plus"></span> Add Role</a></li>
</ul>
<?php $__env->stopSection(); ?>