<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="white-box">
                
                <?php if (\Entrust::can('user-add')) : ?>
                    <div>
                        <h3 class="box-title">
                            <a class="btn btn-sm btn-primary" href="user/create">
                                Add User
                            </a>
                        </h3>
                    </div>
                <?php endif; // Entrust::can ?>
                <div class="table-responsive">
                    <table id="example1" class="table">
                        <?php if($items->count()): ?>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Fisrt Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Last Login</th>
                                <th>Login Type</th>
                                <th width="120">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($srno++); ?></td>
                                <td><?php echo e($value->first_name); ?></td>
                                <td><?php echo e($value->last_name); ?></td>
                                <td><?php echo e($value->email); ?></td>
                                <td><?php echo e($value->last_login); ?></td>
                                <td><?php echo e($value->provider); ?></td>
                                <td>
                                <?php if (\Entrust::can('user-edit')) : ?>
                                    <?php echo Form::open(array('url' => 'user/'.$value->id,'method'=>'delete','class'=>'form-inline')); ?>

                                         <a href="<?php echo e(url('user/'.$value->id.'/edit')); ?>" class="btn btn-small btn-primary">Edit</a>
                                    <?php echo Form::close(); ?>

                                <?php endif; // Entrust::can ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php else: ?>
                        <tbody>
                            <tr>
                                <th>There are no records</th>
                            </tr>
                        </tbody>
                        <?php endif; ?>
                    </table>
                </div>
                <?php echo str_replace('/?', '?', $items->appends(Request::except(array('page')))->render()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>