<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="white-box">
                
                <div>
                    <h3 class="box-title">
                    <a class="btn btn-sm btn-primary" href="<?php echo e('permission/create'); ?>">
                        Add Permission
                    </a>
                    </h3>
                </div>
                
                <table id="example1" class="table table-bordered table-condensed">
                    <?php if($items->count()): ?>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Display Name</th>
                            <th>Description</th>
                            <th width="120"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($srno++); ?></td>
                            <th><?php echo e($value->name); ?></th>
                            <td><?php echo e($value->display_name); ?></td>
                            <td><?php echo e($value->description); ?></td>
                            <td>
                                <?php echo Form::open(array('url' => $ctrl_url.'/'.$value->id,'method'=>'delete','class'=>'form-inline')); ?>

                                <a href="<?php echo e(url($ctrl_url.'/'.$value->id.'/edit')); ?>" class="btn btn-small btn-primary"><span class="glyphicon glyphicon-pencil"></span></a>
                                <button type="submit" class="btn btn-danger delete-confirm"><span class="glyphicon glyphicon-trash"></span></button>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <?php else: ?>
                    <tbody>
                        <tr>
                            <th>There are no records</th>
                        </tr>
                    </tbody>
                    <?php endif; ?>
                </table>
                <?php echo str_replace('/?', '?', $items->appends(Request::except(array('page')))->render()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>