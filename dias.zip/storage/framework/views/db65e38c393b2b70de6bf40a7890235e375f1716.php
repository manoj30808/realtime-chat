<div class='box-body'>
    <!-- Name -->
    <div class='row'>
        <!-- Name -->
        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <label class="control-label col-lg-3" for="name">Name</label>
            <div class="col-lg-6">
                <?php echo Form::text('name',null,array('class'=>'form-control')); ?>

                <?php echo $errors->first('name', '<span class="help-block">:message</span>'); ?>

            </div>
        </div>
        <!-- Display Nmae -->
        <div class="form-group <?php echo e($errors->has('display_name') ? 'has-error' : ''); ?>">
            <label class="control-label col-lg-3" for="display_name">Display Name</label>
            <div class="col-lg-6">
                <?php echo Form::text('display_name',null,array('class'=>'form-control')); ?>

                <?php echo $errors->first('display_name', '<span class="help-block">:message</span>'); ?>

            </div>
        </div>
        <!-- Discription -->
        <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
            <label class="control-label col-lg-3" for="description">Description</label>
            <div class="col-lg-6">
                <?php echo Form::textarea('description',null,array('class'=>'form-control','rows'=>'5')); ?>

                <?php echo $errors->first('description', '<span class="help-block">:message</span>'); ?>

            </div>
        </div>
    </div>
</div>