# DAIS-LOGIN
Diametric Laravel Application - Login and Users


## Installation

1) In order to install this project, clone this repository:

2) composer install

3) php artisan db:seed