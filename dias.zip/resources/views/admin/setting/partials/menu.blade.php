@section('secondary-menu')
<ul class="nav navbar-nav navbar-right">
	<li><a href="/user/"><span class="glyphicon glyphicon-align-justify"></span> List</a></li>
	<li><a href="/user/create"><span class="glyphicon glyphicon-plus"></span> Add User</a></li>
</ul>
@stop