<?php
/*CONFIG SETTING BESIC FOR SETUP*/
return [
    'par_page'  => 10,
    'project_full_name' => 'Diametric Data Systems'
];