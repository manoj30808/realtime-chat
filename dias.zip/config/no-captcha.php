<?php

return [
    'secret'  => '6Lez3CIUAAAAALNPJ9U-rCESwLx19TkVoMPiDaVT',
    'sitekey' => '6Lez3CIUAAAAABcHmQP2eIU-9_lI3JCO76hgS3KB',
    'lang'    => 'en', 
];